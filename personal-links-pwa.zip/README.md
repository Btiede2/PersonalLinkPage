# Your Name — Links

A tiny installable PWA that's just an index of your personal links.

## Customize

1. Open `index.html`.
2. Change the page title and the `<h1>Your Name</h1>` / blurb text near the top of `<body>`.
3. Scroll to the `LINKS` array near the bottom of the file and edit it:

   ```js
   const LINKS = [
     { name: "Portfolio", path: "./site", url: "https://example.com" },
     ...
   ];
   ```

   `name` is what's shown, `path` is the small label on the right (purely
   decorative — make it whatever short tag you like), `url` is where it goes.
   Add or remove rows freely.

4. Optional: replace `manifest.json`'s `name`/`short_name` with your own, and
   swap the icons in `icons/` for your own artwork (keep the same filenames
   and sizes: 192×192, 512×512, and a 512×512 "maskable" version, plus a
   180×180 `apple-touch-icon.png`).

## Run it locally

Any static file server works, e.g.:

```
npx serve .
```

or

```
python3 -m http.server 8080
```

Then open the printed localhost URL. Service workers require either
`localhost` or HTTPS, so opening `index.html` directly via `file://` won't
register it (the page still works, just without offline caching).

## Deploy

Upload the whole folder as-is to any static host (GitHub Pages, Netlify,
Vercel, Cloudflare Pages, etc.) — no build step needed.

## Install on a device

Once it's served over HTTPS:

- **iOS Safari:** Share → Add to Home Screen
- **Android Chrome:** menu (⋮) → Install app / Add to Home screen
- **Desktop Chrome/Edge:** install icon in the address bar

## Files

- `index.html` — the page and all styling/logic
- `manifest.json` — name, colors, icons for installability
- `service-worker.js` — caches the app shell so it opens instantly and works offline
- `icons/` — placeholder app icons
